package test;
 
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;


import utils.DateUtils;
import utils.ExcelData;


public class TestBase
{
	public static WebDriver driver;
	public static WebDriverWait wait;
	
	public static WebDriver setupDriver() throws InterruptedException 
	{
		String url = "https://www.tripadvisor.com";
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(); 
		driver.manage().window().maximize();
		
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS); 
		driver.navigate().to(url);
		
		driver.findElement(By.xpath("//*[@id=\"lithium-root\"]/main/div[3]/div[1]/button[2]/span/a")).click();
		Thread.sleep(1000);
		return driver;
	}    
	   
	public static void takeScreenShots() throws IOException 
	{
		TakesScreenshot takeScreenshot = (TakesScreenshot) driver;
		File source = takeScreenshot.getScreenshotAs(OutputType.FILE);
 
		File dest = new File(System.getProperty("user.dir") + "/src/main/resources/Screenshots/"+DateUtils.getTimeStamp()+".png");
				
		FileUtils.copyFile(source, dest);
 
	}
	
	@Test(priority=0)
    public void invokedriver() throws InterruptedException 
	{
          setupDriver();  
    }
 
	@Test(priority=1, enabled=true)
	public void searchBox() {
		String data = new String();
		WebElement searchBox = driver.findElement(By.xpath("//input[@placeholder='Hotel name or destination']"));
		data = ExcelData.readExcel(0);
		searchBox.sendKeys(data);
		searchBox.sendKeys(Keys.TAB);
	} 
    
	@Test(priority=2, enabled=true)  
	public void checkIn() throws InterruptedException 
	{ 
		driver.findElement((By.xpath("//*[@data-datetype='CHECKIN']"))).click();
		Thread.sleep(2000);
		  
		String data = ExcelData.readExcel(1);
		String checkinDate = data.substring(3, 11);
		String dateval = data.substring(0, 2); 
		 
		while(true) 
		{
			String txt=driver.findElement(By.xpath("//*[@id=\"BODY_BLOCK_JQUERY_REFLOW\"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]")).getText();
			
			if(txt.equalsIgnoreCase(checkinDate))
				break;//*[@id="BODY_BLOCK_JQUERY_REFLOW"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]
			else
				driver.findElement(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[1]")).click();
			
		}
		 
		List<WebElement> datelist = driver.findElements(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[3]/span[1]/span"));
		for(WebElement element:datelist) 
		{
			String date = element.getText();
			if(date.equals(dateval)) {
				Thread.sleep(1000);
				element.click();
				break;
			}
		}	   
	} 
	   
	@Test(priority=3, enabled=true)
	public void checkOut() throws InterruptedException 
	{
		driver.findElement((By.xpath("//*[@data-datetype='CHECKOUT']"))).click();
		Thread.sleep(2000);
		
		String data = ExcelData.readExcel(2);
		String checkoutDate = data.substring(3, 11);
		String dateval = data.substring(0, 2);  
		while(true) 
		{
			String txt=driver.findElement(By.xpath("//*[@id=\"BODY_BLOCK_JQUERY_REFLOW\"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]")).getText();
			
			if(txt.equalsIgnoreCase(checkoutDate))
				break;//*[@id="BODY_BLOCK_JQUERY_REFLOW"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]
			else
				driver.findElement(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[1]")).click();
			
		}	
		
		List<WebElement> datelist = driver.findElements(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[3]/span[1]/span"));
		for(WebElement element:datelist) 
		{
			String date = element.getText();
			if(date.equals(dateval)) 
			{
				Thread.sleep(1000);
				element.click();
				break;
			}
		}	
	}
	
	@Test(priority=4, enabled=true)
	public void rooms() 
	{
		WebElement number = driver.findElement((By.xpath("//*[@class=\'ui_icon caret-down\']")));
		number.click();
		String data = new String();
		data = ExcelData.readExcel(3);
		int data1 = Integer.parseInt(data);
		WebElement room = driver.findElement((By.xpath("//*[@id=\'BODY_BLOCK_JQUERY_REFLOW\']/span/div[3]/div/div[1]/div/span[2]")));
		String rum = room.getText();
		char c = rum.charAt(0);
		int Room = Character.getNumericValue(c);
		while(data1!=Room) 
		{
			if(data1 > Room) 
			{
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.roomsPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle"))).click();
			}
			else if(data1 < Room)
			{
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.roomsPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle"))).click();
			}
			rum = room.getText();
			c = rum.charAt(0);
			Room = Character.getNumericValue(c);
		}
	}
	
	@Test(dependsOnMethods= {"rooms"}, priority=5, enabled=true)
	public void adults() 
	{
		WebElement adult = driver.findElement((By.xpath("//*[@id=\'BODY_BLOCK_JQUERY_REFLOW\']/span/div[3]/div/div[2]/div/span[2]")));
		String adlt = adult.getText();
		char c = adlt.charAt(0);
		int Adult = Character.getNumericValue(c);
		String data = ExcelData.readExcel(4);
		int data1 = Integer.parseInt(data);
		while(data1!=Adult) 
		{
			if(data1 > Adult) 
			{
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.adultsPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle"))).click();
			}
			else if(data1 < Adult) {
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.adultsPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle"))).click();
			}
			adlt = adult.getText();
			c = adlt.charAt(0);
			Adult = Character.getNumericValue(c);
		}
	}	
	
	@Test(dependsOnMethods= {"rooms"}, priority=6, enabled=true)
	public void children() 
	{
		WebElement child = driver.findElement((By.xpath("//*[@id=\'BODY_BLOCK_JQUERY_REFLOW\']/span/div[3]/div/div[3]/div/span[2]")));
		String chld = child.getText();
		char c = chld.charAt(0);
		int Child = Character.getNumericValue(c);
		String data = ExcelData.readExcel(5);
		int data1 = Integer.parseInt(data);
		while(data1!=Child) {
			if(data1 > Child) {
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.childrenPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle"))).click();
			}
			else if(data1 < Child) {
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.childrenPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle.inactive"))).click();
			}
			chld = child.getText();
			c = chld.charAt(0);
			Child = Character.getNumericValue(c);
		}	

		driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.ages-wrap > span > span > span.picker-inner"))).click();
		driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.ages-wrap > span > span > div > span > ul.options-container > li:nth-child(8)"))).click();
	}
	@AfterTest
	public void quit() throws IOException, InterruptedException {
		Thread.sleep(3000);
		takeScreenShots();
		driver.quit();
	}
}
