package utils;
 
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
 
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
import test.TestBase;
 
public class ExcelData extends TestBase 
{
	public static File file;
	public static FileInputStream work_file;
	public static XSSFWorkbook workbook;
	public static XSSFSheet worksheet;
	public static XSSFRow row;
	public static Cell cell;
	public static FileOutputStream result_file;
	
	/********Method to read data from the 'Excel Sheet'**************************/
  
	public static String readExcel(int num) 
	{
 
		String data1 = null;
		String[] data = new String[5];
		try {
			String filepath = System.getProperty("user.dir") + "\\src\\main\\resources\\Excel\\Booking_1.xlsx";
			file = new File(filepath);
			work_file = new FileInputStream(file);
			workbook = new XSSFWorkbook(work_file);
			worksheet = workbook.getSheet("Sheet1");
			row = worksheet.getRow(1);
			cell = row.getCell(num);
			data1 = cell.getStringCellValue();
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data1;
	}
}