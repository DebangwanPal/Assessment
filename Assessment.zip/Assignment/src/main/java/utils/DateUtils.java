package utils;
 
import java.util.Date;
 
public class DateUtils {
	/**********************************************************************************
	 * Method to print 'Date' as filename for HTML report 
	 **********************************************************************************/
	public static String getTimeStamp() {
		Date date =new Date();
		return ( date.toString().replaceAll(" ", "_").replaceAll(":", "_"));
	}
 
}